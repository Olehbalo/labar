package ua.lviv.iot.sport;


public enum KindOfSport {
    AllAround,
    SportWithFinishLine
}

    
