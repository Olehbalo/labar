package ua.lviv.iot.sport;


public enum SortOrder {
    ASC,
    DESC
}